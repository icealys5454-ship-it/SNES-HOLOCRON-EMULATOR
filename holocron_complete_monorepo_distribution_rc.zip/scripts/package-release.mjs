
import fs from "node:fs";
import crypto from "node:crypto";

if (!fs.existsSync("dist")) throw new Error("Run npm run build first.");

function walk(dir) {
  return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e => {
    const p = `${dir}/${e.name}`;
    return e.isDirectory() ? walk(p) : [p];
  });
}
const artifacts = walk("dist").map(path => ({
  path,
  bytes: fs.statSync(path).size,
  sha256: crypto.createHash("sha256").update(fs.readFileSync(path)).digest("hex")
}));
const manifest = {
  schema:"holocron.release.manifest.v1",
  version:"1.0.0-rc.1",
  generated_at:new Date().toISOString(),
  qualification:"release-candidate / core-not-yet-production-qualified",
  artifacts
};
fs.writeFileSync("release/release-manifest.json",JSON.stringify(manifest,null,2));
console.log("Wrote release/release-manifest.json");
