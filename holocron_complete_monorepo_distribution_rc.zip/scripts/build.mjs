
import fs from "node:fs";
import path from "node:path";

fs.rmSync("dist",{recursive:true,force:true});
fs.mkdirSync("dist/core",{recursive:true});
fs.mkdirSync("dist/cms",{recursive:true});
fs.mkdirSync("dist/packages",{recursive:true});

fs.cpSync("apps/cms/public","dist/cms",{recursive:true});
fs.cpSync("apps/cms/src","dist/cms/src",{recursive:true});
fs.copyFileSync("packages/core-wasm/dist/holocron-snes-core.wasm","dist/core/holocron-snes-core.wasm");

for (const pkg of ["sdk","webgl","input","storage","compatibility","runtime","config"]) {
  fs.mkdirSync(`dist/packages/${pkg}`,{recursive:true});
  fs.cpSync(`packages/${pkg}/src`,`dist/packages/${pkg}/src`,{recursive:true});
  fs.copyFileSync(`packages/${pkg}/package.json`,`dist/packages/${pkg}/package.json`);
}

console.log("Built dist/");
