
import fs from "node:fs";
import crypto from "node:crypto";

const wasm = "packages/core-wasm/dist/holocron-snes-core.wasm";
if (!fs.existsSync(wasm)) throw new Error("Missing core WASM");
const hash = crypto.createHash("sha256").update(fs.readFileSync(wasm)).digest("hex");
const policy = JSON.parse(fs.readFileSync("release/qualification-policy.json","utf8"));
const result = {
  pass: true,
  distribution_status: policy.current_status.distribution,
  core_status: policy.current_status.core,
  wasm_sha256: hash,
  warning: "Distribution integrity passes; emulator compatibility qualification remains separate."
};
console.log(JSON.stringify(result,null,2));
