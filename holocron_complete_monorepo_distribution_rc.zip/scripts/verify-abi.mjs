
import { readFile } from "node:fs/promises";
const bytes = await readFile("packages/core-wasm/dist/holocron-snes-core.wasm");
const { instance } = await WebAssembly.instantiate(bytes,{});
const e = instance.exports;
const required = [
  "abi_version_major","abi_version_minor","abi_version_patch","status_last",
  "rom_upload_ptr","rom_upload_capacity","load_rom_from_upload","reset","run_frame",
  "framebuffer_ptr","framebuffer_width","framebuffer_height","framebuffer_stride","framebuffer_format",
  "set_controller1","audio_available_frames","audio_peek_ptr","audio_peek_contiguous_frames",
  "audio_consume","audio_sample_rate","audio_channels","state_size","state_ptr","save_state","load_state"
];
const missing = required.filter(name => typeof e[name] !== "function");
const result = { pass: missing.length === 0 && e.abi_version_major() === 1, version:[e.abi_version_major(),e.abi_version_minor(),e.abi_version_patch()].join("."), missing };
console.log(JSON.stringify(result,null,2));
if (!result.pass) process.exit(1);
