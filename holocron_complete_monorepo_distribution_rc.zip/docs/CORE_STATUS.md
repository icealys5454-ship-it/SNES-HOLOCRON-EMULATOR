# Core Status

The current bundled core is the latest unified development core from the HOLOCRON build sequence.

Implemented in development form:
- 65C816 subset with multiple addressing families
- shared master-clock model
- scanline PPU renderer
- VRAM/CGRAM framebuffer path
- 8-channel DMA/HDMA structures
- controller serial/auto-joypad scaffolding
- stereo audio ring boundary
- full machine-state serialization
- stable ABI 1.0.0

Still incomplete for production hardware accuracy:
- complete CPU matrix/timing
- accurate PPU modes/sprites/windows/color math/Mode 7
- exact DMA/HDMA behavior
- SPC700/S-DSP
- full cartridge mapping/SRAM/enhancement chips
- large compatibility qualification corpus
