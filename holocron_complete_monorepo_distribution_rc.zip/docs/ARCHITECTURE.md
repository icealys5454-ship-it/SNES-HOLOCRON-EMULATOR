# Architecture

```text
CMS
 |
 +-- ordered library filters
 |
 +-- launch/runtime
      |
      +-- Gamepad -> SNES controller register
      +-- WebGL <- RGBA framebuffer
      +-- Audio <- S16 stereo ring
      +-- State <-> IndexedDB
      |
      +-- Stable ABI 1.x
             |
             +-- SNES WebAssembly Core
```

The stable ABI is the dependency inversion boundary. Browser code does not depend on CPU/PPU internal structures.
