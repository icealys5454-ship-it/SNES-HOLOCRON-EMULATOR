
export class HolocronCore {
  constructor() {
    this.instance = null;
    this.e = null;
    this.memory = null;
  }

  async open(source) {
    let bytes;
    if (source instanceof ArrayBuffer) {
      bytes = source;
    } else if (ArrayBuffer.isView(source)) {
      bytes = source.buffer.slice(source.byteOffset, source.byteOffset + source.byteLength);
    } else if (typeof source === "string") {
      if (source.startsWith("file:") && typeof process !== "undefined") {
        const { readFile } = await import("node:fs/promises");
        bytes = (await readFile(new URL(source))).buffer;
      } else {
        bytes = await (await fetch(source)).arrayBuffer();
      }
    } else {
      throw new TypeError("Expected URL string, ArrayBuffer, or typed array");
    }

    const result = await WebAssembly.instantiate(bytes, {});
    this.instance = result.instance;
    this.e = this.instance.exports;
    this.memory = this.e.memory;

    if (!this.memory) throw new Error("ABI violation: memory export missing.");
    const version = this.version();
    if (version.major !== 1) throw new Error(`Unsupported ABI major ${version.major}.`);
    return this;
  }

  version() {
    return {
      major: this.e.abi_version_major(),
      minor: this.e.abi_version_minor(),
      patch: this.e.abi_version_patch(),
    };
  }

  reset() { this.e.reset(); }

  loadRom(bytes) {
    const cap = this.e.rom_upload_capacity();
    if (!bytes?.byteLength) throw new Error("ROM is empty.");
    if (bytes.byteLength > cap) throw new Error(`ROM exceeds ${cap} byte upload capacity.`);
    new Uint8Array(this.memory.buffer, this.e.rom_upload_ptr(), bytes.byteLength).set(bytes);
    const rc = this.e.load_rom_from_upload(bytes.byteLength);
    if (rc !== 0) throw new Error(`ROM load failed with status ${rc}.`);
  }

  runFrame() {
    const rc = this.e.run_frame();
    if (rc !== 0) throw new Error(`Frame failed with status ${rc}.`);
  }

  setController1(mask) { this.e.set_controller1(mask & 0xffff); }

  framebuffer() {
    const width = this.e.framebuffer_width();
    const height = this.e.framebuffer_height();
    return {
      width,
      height,
      stride: this.e.framebuffer_stride(),
      format: this.e.framebuffer_format(),
      pixels: new Uint8Array(this.memory.buffer, this.e.framebuffer_ptr(), width * height * 4)
    };
  }

  pullAudio(maxFrames = 1024) {
    const available = this.e.audio_available_frames();
    let remain = Math.min(available, maxFrames);
    const chunks = [];
    while (remain > 0) {
      const n = Math.min(remain, this.e.audio_peek_contiguous_frames());
      if (!n) break;
      chunks.push(new Int16Array(
        new Int16Array(this.memory.buffer, this.e.audio_peek_ptr(), n * 2)
      ));
      this.e.audio_consume(n);
      remain -= n;
    }
    const totalSamples = chunks.reduce((n, c) => n + c.length, 0);
    const samples = new Int16Array(totalSamples);
    let offset = 0;
    for (const chunk of chunks) {
      samples.set(chunk, offset);
      offset += chunk.length;
    }
    return {
      frames: totalSamples / 2,
      channels: this.e.audio_channels(),
      sampleRate: this.e.audio_sample_rate(),
      samples
    };
  }

  saveState() {
    const n = this.e.save_state();
    if (!n) throw new Error("Save state failed.");
    return new Uint8Array(this.memory.buffer, this.e.state_ptr(), n).slice();
  }

  loadState(bytes) {
    if (bytes.byteLength > this.e.state_size()) throw new Error("State exceeds core buffer.");
    new Uint8Array(this.memory.buffer, this.e.state_ptr(), bytes.byteLength).set(bytes);
    const rc = this.e.load_state();
    if (rc !== 0) throw new Error(`Load state failed with status ${rc}.`);
  }
}

export class OrderedFilterPipeline {
  constructor() { this.filters = []; }
  use(filter) {
    this.filters.push(filter);
    this.filters.sort((a,b) => (a.order - b.order) || a.id.localeCompare(b.id));
    return this;
  }
  run(items, context = {}) {
    let out = [...items];
    for (const filter of this.filters) out = filter.apply(out, context);
    return out;
  }
}

export class QueryFilter {
  id = "query";
  order = 100;
  constructor(textSelector) { this.textSelector = textSelector; }
  apply(items, ctx) {
    const q = String(ctx.query ?? "").trim().toLowerCase();
    return q ? items.filter(x => this.textSelector(x).toLowerCase().includes(q)) : [...items];
  }
}

export class CompatibilityFilter {
  id = "compatibility";
  order = 400;
  apply(items, ctx) {
    const min = Number(ctx.minCompatibility ?? 0);
    return items.filter(x => Number(x.compatibility ?? 0) >= min);
  }
}

export class SortFilter {
  id = "sort";
  order = 900;
  constructor(selector, direction = "asc") {
    this.selector = selector;
    this.direction = direction;
  }
  apply(items) {
    const sign = this.direction === "desc" ? -1 : 1;
    return [...items].sort((a,b) => {
      const av = this.selector(a), bv = this.selector(b);
      return (av < bv ? -1 : av > bv ? 1 : 0) * sign;
    });
  }
}
