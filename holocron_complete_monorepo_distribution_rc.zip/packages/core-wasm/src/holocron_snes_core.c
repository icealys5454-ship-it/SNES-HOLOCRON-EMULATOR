
#include <stdint.h>
typedef unsigned int size_t;
__attribute__((used,noinline)) void *memset(void*s,int c,size_t n){uint8_t*p=(uint8_t*)s;for(size_t i=0;i<n;i++)p[i]=(uint8_t)c;return s;}
__attribute__((used,noinline)) void *memcpy(void*d,const void*s,size_t n){uint8_t*D=(uint8_t*)d;const uint8_t*S=(const uint8_t*)s;for(size_t i=0;i<n;i++)D[i]=S[i];return d;}

#define ABI_MAJOR 1u
#define ABI_MINOR 0u
#define ABI_PATCH 0u

#define STATUS_OK 0u
#define ERR_NO_ROM 1u
#define ERR_ROM_TOO_LARGE 2u
#define ERR_BAD_STATE 3u
#define ERR_NOT_READY 4u

#define FBW 256u
#define FBH 224u
#define FB_BYTES (FBW*FBH*4u)
#define ROM_MAX 8388608u
#define WRAM 131072u
#define VRAM 65536u
#define CGRAM 512u
#define OAM 544u
#define AUDIO_CAP_FRAMES 4096u
#define AUDIO_CH 2u
#define STATE_MAX 214000u

#define F_C 0x01u
#define F_Z 0x02u
#define F_I 0x04u
#define F_D 0x08u
#define F_X 0x10u
#define F_M 0x20u
#define F_V 0x40u
#define F_N 0x80u

typedef struct{
  uint16_t a,x,y,s,d,pc;
  uint8_t p,db,pb,e,halted,waiting;
  uint64_t cycles;
  uint16_t controller1;
  uint16_t controller_latched;
  uint16_t controller_shift;
  uint8_t controller_strobe;
  uint16_t joy_auto;
} CPU;

typedef struct{
  uint64_t master;
  uint16_t dot,line;
  uint8_t hblank,vblank,nmi,irq;
  uint32_t frame;
} CLOCK;

typedef struct{
  uint8_t mode,tm,ts,mosaic,bgmode;
  uint16_t vaddr;
  uint8_t cgaddr;
  uint8_t cgwsel,cgadsub,fixed_r,fixed_g,fixed_b;
  uint8_t wh0,wh1,wh2,wh3,w12sel,w34sel,wobjsel;
} PPU;

typedef struct{
  uint8_t enabled,control,dest;
  uint32_t src;
  uint16_t size;
  uint32_t bytes;
} DMA_CH;

typedef struct{
  uint8_t enabled,control,dest,line_count,repeat;
  uint32_t table,indirect_addr;
  uint32_t bytes;
} HDMA_CH;

typedef struct{
  uint64_t clocks;
  uint32_t samples;
  uint32_t phase;
} APU;

typedef struct{
  uint32_t magic;
  CPU cpu;
  CLOCK clk;
  PPU ppu;
  DMA_CH dma[8];
  HDMA_CH hdma[8];
  APU apu;
  uint32_t rom_size;
  uint32_t audio_write,audio_read,audio_count;
} STATE_HDR;

static CPU cpu;
static CLOCK clk;
static PPU ppu;
static DMA_CH dma[8];
static HDMA_CH hdma[8];
static APU apu;
static uint8_t rom[ROM_MAX],rom_upload[ROM_MAX];
static uint32_t rom_size,last_status;
static uint8_t wram[WRAM],vram[VRAM],cgram[CGRAM],oam[OAM],fb[FB_BYTES],statebuf[STATE_MAX];
static int16_t audio_ring[AUDIO_CAP_FRAMES*AUDIO_CH];
static uint32_t audio_write,audio_read,audio_count;

static void set_status(uint32_t s){last_status=s;}
static void zn8(uint8_t v){if(v)cpu.p&=~F_Z;else cpu.p|=F_Z;if(v&0x80)cpu.p|=F_N;else cpu.p&=~F_N;}
static void enforce(void){if(cpu.e){cpu.p|=(F_M|F_X);cpu.s=0x0100|(cpu.s&255);}if(cpu.p&F_X){cpu.x&=255;cpu.y&=255;}}
static uint8_t rb(uint32_t a){
  uint8_t b=(uint8_t)(a>>16);uint16_t o=(uint16_t)a;
  if(b==0x7e||b==0x7f)return wram[((uint32_t)(b-0x7e)<<16)|o];
  if((b<0x40||(b>=0x80&&b<0xc0))&&o>=0x8000&&rom_size){
    uint32_t i=(((uint32_t)(b&127)<<15)|(o-0x8000));
    return rom[i%rom_size];
  }
  if((b==0||b==0x80) && o==0x4016){
    uint8_t bit=(uint8_t)(cpu.controller_shift&1u);
    if(!cpu.controller_strobe)cpu.controller_shift=(uint16_t)((cpu.controller_shift>>1)|0x8000u);
    return bit;
  }
  if((b==0||b==0x80) && o==0x4218)return (uint8_t)cpu.joy_auto;
  if((b==0||b==0x80) && o==0x4219)return (uint8_t)(cpu.joy_auto>>8);
  return wram[o];
}
static void wb(uint32_t a,uint8_t v){
  uint8_t b=(uint8_t)(a>>16);uint16_t o=(uint16_t)a;
  if((b==0||b==0x80) && o==0x4016){
    uint8_t ns=v&1u;
    if(ns){cpu.controller_strobe=1;cpu.controller_shift=cpu.controller1;}
    else{if(cpu.controller_strobe)cpu.controller_shift=cpu.controller1;cpu.controller_strobe=0;}
    return;
  }
  if(b==0x7e||b==0x7f){wram[((uint32_t)(b-0x7e)<<16)|o]=v;return;}
  wram[o]=v;
}
static uint8_t f8(void){uint8_t v=rb(((uint32_t)cpu.pb<<16)|cpu.pc);cpu.pc++;return v;}
static uint16_t f16(void){uint16_t l=f8(),h=f8();return l|((uint16_t)h<<8);}
static uint32_t f24(void){uint32_t l=f8(),m=f8(),h=f8();return l|(m<<8)|(h<<16);}
static void push8(uint8_t v){wb(0x7e0000u|cpu.s,v);cpu.s--;enforce();}
static uint8_t pull8(void){cpu.s++;enforce();return rb(0x7e0000u|cpu.s);}
static void push16(uint16_t v){push8((uint8_t)(v>>8));push8((uint8_t)v);}
static uint16_t pull16(void){uint8_t l=pull8(),h=pull8();return l|((uint16_t)h<<8);}

static uint32_t ea_dp(void){return (uint16_t)(cpu.d+f8());}
static uint32_t ea_dpx(void){return (uint16_t)(cpu.d+(uint8_t)(f8()+cpu.x));}
static uint32_t ea_abs(void){return ((uint32_t)cpu.db<<16)|f16();}
static uint32_t ea_absx(void){return ((uint32_t)cpu.db<<16)|(uint16_t)(f16()+cpu.x);}
static uint32_t ea_absy(void){return ((uint32_t)cpu.db<<16)|(uint16_t)(f16()+cpu.y);}
static uint32_t ea_long(void){return f24();}

static void audio_push(int16_t l,int16_t r){
  if(audio_count>=AUDIO_CAP_FRAMES){audio_read=(audio_read+1u)%AUDIO_CAP_FRAMES;audio_count--;}
  uint32_t i=audio_write*2u;audio_ring[i]=l;audio_ring[i+1]=r;audio_write=(audio_write+1u)%AUDIO_CAP_FRAMES;audio_count++;
}
static void apu_tick(uint32_t master){
  apu.clocks+=master;
  while(apu.clocks>=768u){
    apu.clocks-=768u;apu.samples++;apu.phase=(apu.phase+31u)&1023u;
    int16_t l=(apu.phase<512u)?1800:-1800;
    int16_t r=((apu.phase+128u)&1023u)<512u?1500:-1500;
    audio_push(l,r);
  }
}
static uint16_t cg(uint8_t i){uint32_t a=((uint32_t)i*2u)&511u;return (uint16_t)(cgram[a]|((uint16_t)cgram[(a+1u)&511u]<<8));}
static uint16_t fixed_color(void){return (uint16_t)((ppu.fixed_r&31u)|((ppu.fixed_g&31u)<<5)|((ppu.fixed_b&31u)<<10));}
static void rgba(uint16_t c,uint8_t*o){o[0]=(uint8_t)((c&31u)<<3);o[1]=(uint8_t)(((c>>5)&31u)<<3);o[2]=(uint8_t)(((c>>10)&31u)<<3);o[3]=255;}
static uint16_t add_color(uint16_t a,uint16_t b){
  uint16_t r=(a&31u)+(b&31u),g=((a>>5)&31u)+((b>>5)&31u),bl=((a>>10)&31u)+((b>>10)&31u);
  if(r>31)r=31;if(g>31)g=31;if(bl>31)bl=31;return (uint16_t)(r|(g<<5)|(bl<<10));
}
static uint16_t sub_color(uint16_t a,uint16_t b){
  int r=(int)(a&31u)-(int)(b&31u),g=(int)((a>>5)&31u)-(int)((b>>5)&31u),bl=(int)((a>>10)&31u)-(int)((b>>10)&31u);
  if(r<0)r=0;if(g<0)g=0;if(bl<0)bl=0;return (uint16_t)(r|(g<<5)|(bl<<10));
}
static uint8_t t2(uint16_t tile,uint8_t x,uint8_t y){
  uint32_t b=((uint32_t)tile*16u)&0xffffu,bit=7u-x;
  uint8_t a=vram[(b+y*2u)&0xffffu],d=vram[(b+y*2u+1u)&0xffffu];
  return (uint8_t)(((a>>bit)&1u)|(((d>>bit)&1u)<<1));
}
static uint8_t t4(uint16_t tile,uint8_t x,uint8_t y){
  uint32_t b=((uint32_t)tile*32u)&0xffffu,bit=7u-x;
  uint8_t p0=vram[(b+y*2u)&0xffffu],p1=vram[(b+y*2u+1u)&0xffffu],p2=vram[(b+16u+y*2u)&0xffffu],p3=vram[(b+17u+y*2u)&0xffffu];
  return (uint8_t)(((p0>>bit)&1u)|(((p1>>bit)&1u)<<1)|(((p2>>bit)&1u)<<2)|(((p3>>bit)&1u)<<3));
}
static int in_window(uint32_t x){
  int w1=(x>=ppu.wh0&&x<=ppu.wh1),w2=(x>=ppu.wh2&&x<=ppu.wh3);
  return w1||w2;
}
static uint16_t apply_color_math(uint16_t main,uint32_t x){
  if(!(ppu.cgadsub&0x80u))return main;
  if((ppu.cgwsel&0x20u)&&!in_window(x))return main;
  uint16_t sub=fixed_color();
  return (ppu.cgadsub&0x40u)?sub_color(main,sub):add_color(main,sub);
}
static void render_scanline(uint16_t y){
  if(y>=FBH)return;
  for(uint32_t x=0;x<FBW;x++)rgba(cg(0),&fb[(y*FBW+x)*4u]);
  uint8_t mode=ppu.mode,bpp=(mode==0)?2:4;
  for(int layer=3;layer>=0;layer--){
    if(!(ppu.tm&(1u<<layer)))continue;
    uint8_t pri_base=(uint8_t)(layer*2);
    for(uint32_t x=0;x<FBW;x++){
      uint32_t tx=x>>3,ty=y>>3,mi=((ty&31u)*32u+(tx&31u))*2u;
      uint16_t e=(uint16_t)(vram[mi&0xffffu]|((uint16_t)vram[(mi+1u)&0xffffu]<<8));
      uint16_t tile=e&0x3ffu;uint8_t pal=(e>>10)&7u,px=x&7u,py=y&7u;
      if(e&0x4000u)px=7u-px;if(e&0x8000u)py=7u-py;
      uint8_t ci=bpp==2?t2(tile,px,py):t4(tile,px,py);if(!ci)continue;
      uint8_t idx=(uint8_t)(bpp==2?pal*4u+ci:pal*16u+ci);
      uint16_t col=apply_color_math(cg(idx),x);
      rgba(col,&fb[(y*FBW+x)*4u]);
      (void)pri_base;
    }
  }
}
static void ppu_data_write(uint8_t dest,uint8_t v){
  if(dest==0x18)vram[(ppu.vaddr<<1)&0xffffu]=v;
  else if(dest==0x19){vram[((ppu.vaddr<<1)+1u)&0xffffu]=v;ppu.vaddr++;}
  else if(dest==0x22){uint32_t a=((uint32_t)ppu.cgaddr*2u)&511u;cgram[a]=v;ppu.cgaddr++;}
}
static uint8_t dma_dest_offset(uint8_t mode,uint32_t i){
  static const uint8_t pat[8][4]={{0,0,0,0},{0,1,0,1},{0,0,0,0},{0,0,1,1},{0,1,2,3},{0,1,0,1},{0,0,0,0},{0,0,1,1}};
  return pat[mode&7u][i&3u];
}
static void hdma_scanline(void){
  for(uint32_t ch=0;ch<8;ch++){
    HDMA_CH*h=&hdma[ch];
    if(!h->enabled)continue;
    if(h->line_count==0){
      uint8_t desc=rb(h->table++);
      if(desc==0){h->enabled=0;continue;}
      h->repeat=(desc&0x80u)?1u:0u;h->line_count=(uint8_t)(desc&0x7fu);
      if(h->line_count==0)h->line_count=128;
      if(h->control&0x40u){
        uint8_t lo=rb(h->table++),hi=rb(h->table++);
        h->indirect_addr=(h->indirect_addr&0xff0000u)|lo|((uint32_t)hi<<8);
      }
    }
    uint8_t mode=h->control&7u;
    uint32_t count=(mode==0||mode==2||mode==6)?1u:(mode==1||mode==5)?2u:4u;
    for(uint32_t i=0;i<count;i++){
      uint32_t src=(h->control&0x40u)?h->indirect_addr++:h->table++;
      uint8_t v=rb(src);ppu_data_write((uint8_t)(h->dest+dma_dest_offset(mode,i)),v);h->bytes++;clk.master+=8;apu_tick(8);
    }
    if(h->line_count)h->line_count--;
  }
}
static void auto_joypad_poll(void){
  cpu.joy_auto=cpu.controller1;
}
static void tick(uint32_t master){
  for(uint32_t i=0;i<master;i++){
    clk.master++;apu_tick(1);
    if((clk.master&3u)==0){
      clk.dot++;if(clk.dot==274)clk.hblank=1;
      if(clk.dot>=341){
        clk.dot=0;clk.hblank=0;hdma_scanline();render_scanline(clk.line);clk.line++;
        if(clk.line==225){clk.vblank=1;clk.nmi=1;auto_joypad_poll();}
        if(clk.line>=262){clk.line=0;clk.vblank=0;clk.nmi=0;clk.frame++;}
      }
    }
  }
}
static void vector(uint16_t v){
  push8(cpu.pb);push16(cpu.pc);push8(cpu.p);cpu.pb=0;cpu.p|=F_I;cpu.p&=~F_D;
  cpu.pc=(uint16_t)(rb(v)|((uint16_t)rb((uint16_t)(v+1))<<8));
}
static void service_interrupts(void){
  if(cpu.waiting&&(clk.nmi||clk.irq))cpu.waiting=0;
  if(clk.nmi){clk.nmi=0;vector(cpu.e?0xfffa:0xffea);cpu.cycles+=7;tick(42);}
}
static uint8_t adc8(uint8_t a,uint8_t b){uint16_t r=(uint16_t)a+b+(cpu.p&F_C?1:0);if(r>255)cpu.p|=F_C;else cpu.p&=~F_C;uint8_t o=(uint8_t)r;zn8(o);return o;}
static uint8_t sbc8(uint8_t a,uint8_t b){int16_t r=(int16_t)a-b-(cpu.p&F_C?0:1);if(r>=0)cpu.p|=F_C;else cpu.p&=~F_C;uint8_t o=(uint8_t)r;zn8(o);return o;}
static uint8_t asl8(uint8_t v){if(v&0x80)cpu.p|=F_C;else cpu.p&=~F_C;v<<=1;zn8(v);return v;}
static uint8_t lsr8(uint8_t v){if(v&1)cpu.p|=F_C;else cpu.p&=~F_C;v>>=1;zn8(v);return v;}
static void cpu_step(void){
  if(cpu.halted||cpu.waiting)return;
  uint8_t op=f8(),v;uint16_t q;uint32_t a;
  switch(op){
    case 0xea:cpu.cycles+=2;tick(12);break;
    case 0x18:cpu.p&=~F_C;cpu.cycles+=2;tick(12);break;
    case 0x38:cpu.p|=F_C;cpu.cycles+=2;tick(12);break;
    case 0x58:cpu.p&=~F_I;cpu.cycles+=2;tick(12);break;
    case 0x78:cpu.p|=F_I;cpu.cycles+=2;tick(12);break;
    case 0xb8:cpu.p&=~F_V;cpu.cycles+=2;tick(12);break;
    case 0xd8:cpu.p&=~F_D;cpu.cycles+=2;tick(12);break;
    case 0xf8:cpu.p|=F_D;cpu.cycles+=2;tick(12);break;
    case 0xc2:cpu.p&=(uint8_t)~f8();enforce();cpu.cycles+=3;tick(18);break;
    case 0xe2:cpu.p|=f8();enforce();cpu.cycles+=3;tick(18);break;
    case 0xfb:{uint8_t oc=(cpu.p&F_C)?1:0,oe=cpu.e?1:0;cpu.e=oc;if(oe)cpu.p|=F_C;else cpu.p&=~F_C;enforce();cpu.cycles+=2;tick(12);break;}

    case 0xa9:v=f8();cpu.a=(cpu.a&0xff00u)|v;zn8(v);cpu.cycles+=2;tick(12);break;
    case 0xa2:v=f8();cpu.x=v;zn8(v);cpu.cycles+=2;tick(12);break;
    case 0xa0:v=f8();cpu.y=v;zn8(v);cpu.cycles+=2;tick(12);break;

    case 0xa5:a=ea_dp();v=rb(a);cpu.a=(cpu.a&0xff00u)|v;zn8(v);cpu.cycles+=3;tick(18);break;
    case 0xb5:a=ea_dpx();v=rb(a);cpu.a=(cpu.a&0xff00u)|v;zn8(v);cpu.cycles+=4;tick(24);break;
    case 0xad:a=ea_abs();v=rb(a);cpu.a=(cpu.a&0xff00u)|v;zn8(v);cpu.cycles+=4;tick(24);break;
    case 0xbd:a=ea_absx();v=rb(a);cpu.a=(cpu.a&0xff00u)|v;zn8(v);cpu.cycles+=4;tick(24);break;
    case 0xb9:a=ea_absy();v=rb(a);cpu.a=(cpu.a&0xff00u)|v;zn8(v);cpu.cycles+=4;tick(24);break;
    case 0xaf:a=ea_long();v=rb(a);cpu.a=(cpu.a&0xff00u)|v;zn8(v);cpu.cycles+=5;tick(30);break;

    case 0x85:a=ea_dp();wb(a,(uint8_t)cpu.a);cpu.cycles+=3;tick(18);break;
    case 0x95:a=ea_dpx();wb(a,(uint8_t)cpu.a);cpu.cycles+=4;tick(24);break;
    case 0x8d:a=ea_abs();wb(a,(uint8_t)cpu.a);cpu.cycles+=4;tick(24);break;
    case 0x9d:a=ea_absx();wb(a,(uint8_t)cpu.a);cpu.cycles+=5;tick(30);break;
    case 0x99:a=ea_absy();wb(a,(uint8_t)cpu.a);cpu.cycles+=5;tick(30);break;
    case 0x8f:a=ea_long();wb(a,(uint8_t)cpu.a);cpu.cycles+=5;tick(30);break;

    case 0x69:v=f8();cpu.a=(cpu.a&0xff00u)|adc8((uint8_t)cpu.a,v);cpu.cycles+=2;tick(12);break;
    case 0xe9:v=f8();cpu.a=(cpu.a&0xff00u)|sbc8((uint8_t)cpu.a,v);cpu.cycles+=2;tick(12);break;
    case 0x29:v=f8();cpu.a=(cpu.a&0xff00u)|((uint8_t)cpu.a&v);zn8((uint8_t)cpu.a);cpu.cycles+=2;tick(12);break;
    case 0x09:v=f8();cpu.a=(cpu.a&0xff00u)|((uint8_t)cpu.a|v);zn8((uint8_t)cpu.a);cpu.cycles+=2;tick(12);break;
    case 0x49:v=f8();cpu.a=(cpu.a&0xff00u)|((uint8_t)cpu.a^v);zn8((uint8_t)cpu.a);cpu.cycles+=2;tick(12);break;
    case 0x0a:cpu.a=(cpu.a&0xff00u)|asl8((uint8_t)cpu.a);cpu.cycles+=2;tick(12);break;
    case 0x4a:cpu.a=(cpu.a&0xff00u)|lsr8((uint8_t)cpu.a);cpu.cycles+=2;tick(12);break;
    case 0x06:a=ea_dp();v=asl8(rb(a));wb(a,v);cpu.cycles+=5;tick(30);break;
    case 0x46:a=ea_dp();v=lsr8(rb(a));wb(a,v);cpu.cycles+=5;tick(30);break;
    case 0x64:a=ea_dp();wb(a,0);cpu.cycles+=3;tick(18);break;
    case 0x9c:a=ea_abs();wb(a,0);cpu.cycles+=4;tick(24);break;

    case 0xe8:cpu.x++;enforce();zn8((uint8_t)cpu.x);cpu.cycles+=2;tick(12);break;
    case 0xca:cpu.x--;enforce();zn8((uint8_t)cpu.x);cpu.cycles+=2;tick(12);break;
    case 0xc8:cpu.y++;enforce();zn8((uint8_t)cpu.y);cpu.cycles+=2;tick(12);break;
    case 0x88:cpu.y--;enforce();zn8((uint8_t)cpu.y);cpu.cycles+=2;tick(12);break;

    case 0xaa:cpu.x=cpu.a;enforce();zn8((uint8_t)cpu.x);cpu.cycles+=2;tick(12);break;
    case 0xa8:cpu.y=cpu.a;enforce();zn8((uint8_t)cpu.y);cpu.cycles+=2;tick(12);break;
    case 0x8a:cpu.a=(cpu.a&0xff00u)|(uint8_t)cpu.x;zn8((uint8_t)cpu.a);cpu.cycles+=2;tick(12);break;
    case 0x98:cpu.a=(cpu.a&0xff00u)|(uint8_t)cpu.y;zn8((uint8_t)cpu.a);cpu.cycles+=2;tick(12);break;
    case 0x9b:cpu.y=cpu.x;enforce();zn8((uint8_t)cpu.y);cpu.cycles+=2;tick(12);break;
    case 0xbb:cpu.x=cpu.y;enforce();zn8((uint8_t)cpu.x);cpu.cycles+=2;tick(12);break;

    case 0x4c:cpu.pc=f16();cpu.cycles+=3;tick(18);break;
    case 0x5c:a=f24();cpu.pb=(uint8_t)(a>>16);cpu.pc=(uint16_t)a;cpu.cycles+=4;tick(24);break;
    case 0x20:q=f16();push16((uint16_t)(cpu.pc-1));cpu.pc=q;cpu.cycles+=6;tick(36);break;
    case 0x60:cpu.pc=(uint16_t)(pull16()+1);cpu.cycles+=6;tick(36);break;

    case 0xd0:{int8_t d=(int8_t)f8();if(!(cpu.p&F_Z))cpu.pc=(uint16_t)(cpu.pc+d);cpu.cycles+=2;tick(12);break;}
    case 0xf0:{int8_t d=(int8_t)f8();if(cpu.p&F_Z)cpu.pc=(uint16_t)(cpu.pc+d);cpu.cycles+=2;tick(12);break;}
    case 0x90:{int8_t d=(int8_t)f8();if(!(cpu.p&F_C))cpu.pc=(uint16_t)(cpu.pc+d);cpu.cycles+=2;tick(12);break;}
    case 0xb0:{int8_t d=(int8_t)f8();if(cpu.p&F_C)cpu.pc=(uint16_t)(cpu.pc+d);cpu.cycles+=2;tick(12);break;}
    case 0x10:{int8_t d=(int8_t)f8();if(!(cpu.p&F_N))cpu.pc=(uint16_t)(cpu.pc+d);cpu.cycles+=2;tick(12);break;}
    case 0x30:{int8_t d=(int8_t)f8();if(cpu.p&F_N)cpu.pc=(uint16_t)(cpu.pc+d);cpu.cycles+=2;tick(12);break;}

    case 0x48:push8((uint8_t)cpu.a);cpu.cycles+=3;tick(18);break;
    case 0x68:v=pull8();cpu.a=(cpu.a&0xff00u)|v;zn8(v);cpu.cycles+=4;tick(24);break;
    case 0xcb:cpu.waiting=1;cpu.cycles+=3;tick(18);break;
    case 0xdb:cpu.halted=1;cpu.cycles+=3;tick(18);break;
    case 0x00:cpu.pc++;vector(cpu.e?0xfffe:0xffe6);cpu.cycles+=7;tick(42);break;
    default:cpu.halted=1;cpu.cycles+=2;tick(12);break;
  }
}
static void dma_run_all(void){
  for(uint32_t ch=0;ch<8;ch++){
    DMA_CH*d=&dma[ch];
    if(!d->enabled)continue;
    uint8_t mode=d->control&7u;
    uint32_t i=0;
    while(d->size){
      uint8_t v=rb(d->src++);ppu_data_write((uint8_t)(d->dest+dma_dest_offset(mode,i++)),v);d->size--;d->bytes++;tick(8);
    }
    d->enabled=0;
  }
}

/* Stable ABI v1.0.0 */
uint32_t abi_version_major(void){return ABI_MAJOR;}
uint32_t abi_version_minor(void){return ABI_MINOR;}
uint32_t abi_version_patch(void){return ABI_PATCH;}
uint32_t status_last(void){return last_status;}
uint32_t status_clear(void){last_status=STATUS_OK;return STATUS_OK;}
uint32_t rom_upload_ptr(void){return (uint32_t)(uintptr_t)rom_upload;}
uint32_t rom_upload_capacity(void){return ROM_MAX;}
uint32_t load_rom_from_upload(uint32_t n){
  if(!n){set_status(ERR_NO_ROM);return ERR_NO_ROM;}
  if(n>ROM_MAX){set_status(ERR_ROM_TOO_LARGE);return ERR_ROM_TOO_LARGE;}
  memcpy(rom,rom_upload,n);rom_size=n;cpu.pc=0x8000;cpu.halted=0;set_status(STATUS_OK);return STATUS_OK;
}
void load_rom(const uint8_t*d,uint32_t n){
  if(!d||!n){set_status(ERR_NO_ROM);return;}
  if(n>ROM_MAX){set_status(ERR_ROM_TOO_LARGE);return;}
  memcpy(rom,d,n);rom_size=n;cpu.pc=0x8000;cpu.halted=0;set_status(STATUS_OK);
}
void reset(void){
  memset(&cpu,0,sizeof(cpu));memset(&clk,0,sizeof(clk));memset(&ppu,0,sizeof(ppu));memset(dma,0,sizeof(dma));memset(hdma,0,sizeof(hdma));memset(&apu,0,sizeof(apu));
  memset(wram,0,sizeof(wram));memset(vram,0,sizeof(vram));memset(cgram,0,sizeof(cgram));memset(oam,0,sizeof(oam));memset(fb,0,sizeof(fb));
  cpu.pc=0x8000;cpu.s=0x1ff;cpu.p=0x34;cpu.e=1;ppu.tm=1;audio_write=audio_read=audio_count=0;set_status(STATUS_OK);
}
uint32_t run_frame(void){
  if(!rom_size){set_status(ERR_NO_ROM);return ERR_NO_ROM;}
  uint32_t start=clk.frame;cpu.controller_latched=cpu.controller1;cpu.controller_shift=cpu.controller1;
  while(clk.frame==start&&!cpu.halted){dma_run_all();cpu_step();service_interrupts();if(cpu.waiting)tick(6);}
  set_status(STATUS_OK);return STATUS_OK;
}
uint32_t framebuffer_ptr(void){return (uint32_t)(uintptr_t)fb;}
uint32_t framebuffer_width(void){return FBW;}
uint32_t framebuffer_height(void){return FBH;}
uint32_t framebuffer_stride(void){return FBW*4u;}
uint32_t framebuffer_format(void){return 1u;}
void set_controller1(uint32_t mask){cpu.controller1=(uint16_t)mask;}
uint32_t get_controller1(void){return cpu.controller1;}
uint32_t get_controller1_latched(void){return cpu.controller_latched;}
uint32_t audio_capacity_frames(void){return AUDIO_CAP_FRAMES;}
uint32_t audio_available_frames(void){return audio_count;}
uint32_t audio_peek_ptr(void){return (uint32_t)(uintptr_t)&audio_ring[audio_read*2u];}
uint32_t audio_peek_contiguous_frames(void){if(!audio_count)return 0;uint32_t n=AUDIO_CAP_FRAMES-audio_read;return audio_count<n?audio_count:n;}
uint32_t audio_consume(uint32_t frames){if(frames>audio_count)frames=audio_count;audio_read=(audio_read+frames)%AUDIO_CAP_FRAMES;audio_count-=frames;return frames;}
uint32_t audio_sample_rate(void){return 31500u;}
uint32_t audio_channels(void){return 2u;}
uint32_t audio_sample_format(void){return 1u;}
uint32_t state_size(void){return (uint32_t)(sizeof(STATE_HDR)+WRAM+VRAM+CGRAM+OAM);}
uint32_t state_ptr(void){return (uint32_t)(uintptr_t)statebuf;}
uint32_t save_state(void){
  uint32_t n=state_size();if(n>STATE_MAX){set_status(ERR_BAD_STATE);return 0;}
  STATE_HDR h;h.magic=0x48343331u;h.cpu=cpu;h.clk=clk;h.ppu=ppu;memcpy(h.dma,dma,sizeof(dma));memcpy(h.hdma,hdma,sizeof(hdma));h.apu=apu;h.rom_size=rom_size;h.audio_write=audio_write;h.audio_read=audio_read;h.audio_count=audio_count;
  uint32_t o=0;memcpy(statebuf+o,&h,sizeof(h));o+=sizeof(h);memcpy(statebuf+o,wram,WRAM);o+=WRAM;memcpy(statebuf+o,vram,VRAM);o+=VRAM;memcpy(statebuf+o,cgram,CGRAM);o+=CGRAM;memcpy(statebuf+o,oam,OAM);o+=OAM;set_status(STATUS_OK);return o;
}
uint32_t load_state(void){
  STATE_HDR h;memcpy(&h,statebuf,sizeof(h));if(h.magic!=0x48343331u){set_status(ERR_BAD_STATE);return ERR_BAD_STATE;}
  cpu=h.cpu;clk=h.clk;ppu=h.ppu;memcpy(dma,h.dma,sizeof(dma));memcpy(hdma,h.hdma,sizeof(hdma));apu=h.apu;rom_size=h.rom_size;audio_write=h.audio_write%AUDIO_CAP_FRAMES;audio_read=h.audio_read%AUDIO_CAP_FRAMES;audio_count=h.audio_count>AUDIO_CAP_FRAMES?AUDIO_CAP_FRAMES:h.audio_count;
  uint32_t o=sizeof(h);memcpy(wram,statebuf+o,WRAM);o+=WRAM;memcpy(vram,statebuf+o,VRAM);o+=VRAM;memcpy(cgram,statebuf+o,CGRAM);o+=CGRAM;memcpy(oam,statebuf+o,OAM);set_status(STATUS_OK);return STATUS_OK;
}

/* Additive diagnostics */
uint32_t diag_cpu_cycles(void){return (uint32_t)cpu.cycles;}
uint32_t diag_frame(void){return clk.frame;}
uint32_t diag_line(void){return clk.line;}
uint32_t diag_dot(void){return clk.dot;}
uint32_t diag_apu_samples(void){return apu.samples;}
uint32_t diag_vram_ptr(void){return (uint32_t)(uintptr_t)vram;}
uint32_t diag_cgram_ptr(void){return (uint32_t)(uintptr_t)cgram;}
uint32_t diag_wram_ptr(void){return (uint32_t)(uintptr_t)wram;}
uint32_t diag_dma_bytes(uint32_t ch){return ch<8?dma[ch].bytes:0;}
uint32_t diag_hdma_bytes(uint32_t ch){return ch<8?hdma[ch].bytes:0;}
void diag_config_dma_channel(uint32_t ch,uint32_t src,uint32_t size,uint32_t dest,uint32_t control){if(ch<8){dma[ch].src=src;dma[ch].size=(uint16_t)size;dma[ch].dest=(uint8_t)dest;dma[ch].control=(uint8_t)control;dma[ch].enabled=1;}}
void diag_config_hdma_channel(uint32_t ch,uint32_t table,uint32_t dest,uint32_t control){if(ch<8){hdma[ch].table=table;hdma[ch].dest=(uint8_t)dest;hdma[ch].control=(uint8_t)control;hdma[ch].line_count=0;hdma[ch].enabled=1;}}
void diag_ppu_write(uint32_t reg,uint32_t v){
  switch(reg){
    case 0x2105:ppu.mode=(uint8_t)(v&7u);ppu.bgmode=(uint8_t)v;break;
    case 0x2106:ppu.mosaic=(uint8_t)v;break;
    case 0x212c:ppu.tm=(uint8_t)v;break;
    case 0x212d:ppu.ts=(uint8_t)v;break;
    case 0x2116:ppu.vaddr=(uint16_t)((ppu.vaddr&0xff00u)|(v&255u));break;
    case 0x2117:ppu.vaddr=(uint16_t)((ppu.vaddr&255u)|((v&255u)<<8));break;
    case 0x2121:ppu.cgaddr=(uint8_t)v;break;
    case 0x2123:ppu.w12sel=(uint8_t)v;break;
    case 0x2124:ppu.w34sel=(uint8_t)v;break;
    case 0x2125:ppu.wobjsel=(uint8_t)v;break;
    case 0x2126:ppu.wh0=(uint8_t)v;break;
    case 0x2127:ppu.wh1=(uint8_t)v;break;
    case 0x2128:ppu.wh2=(uint8_t)v;break;
    case 0x2129:ppu.wh3=(uint8_t)v;break;
    case 0x2130:ppu.cgwsel=(uint8_t)v;break;
    case 0x2131:ppu.cgadsub=(uint8_t)v;break;
    case 0x2132:
      if(v&0x20u)ppu.fixed_r=(uint8_t)(v&31u);
      if(v&0x40u)ppu.fixed_g=(uint8_t)(v&31u);
      if(v&0x80u)ppu.fixed_b=(uint8_t)(v&31u);
      break;
  }
}
uint32_t diag_controller_read4016(void){return rb(0x4016);}
void diag_controller_write4016(uint32_t v){wb(0x4016,(uint8_t)v);}
uint32_t diag_autojoy_low(void){return rb(0x4218);}
uint32_t diag_autojoy_high(void){return rb(0x4219);}
