# @holocron/core-wasm

Current SNES WebAssembly development core behind HOLOCRON ABI v1.0.0.

The package exposes a compiled WASM artifact and C source. The host ABI is stable;
the emulation internals remain under compatibility qualification.

This package is **not yet claimed as cycle-accurate or commercial-game-complete**.
See the repository production qualification document.
