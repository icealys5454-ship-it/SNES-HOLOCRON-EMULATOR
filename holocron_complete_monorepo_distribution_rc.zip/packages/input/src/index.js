
export const defaultSnesProfile = {
  bindings: { B:0, A:1, Y:2, X:3, L:4, R:5, Select:8, Start:9 },
  deadzone: 0.18
};

export function pollSnesMask(profile = defaultSnesProfile, index = 0) {
  const pad = navigator.getGamepads?.()[index];
  if (!pad) return 0;
  const pressed = name => {
    const i = profile.bindings[name];
    return Number.isInteger(i) && Boolean(pad.buttons[i]?.pressed);
  };
  let m = 0;
  if (pressed("B")) m |= 1<<0;
  if (pressed("Y")) m |= 1<<1;
  if (pressed("Select")) m |= 1<<2;
  if (pressed("Start")) m |= 1<<3;
  if ((pad.axes[1] ?? 0) < -0.5) m |= 1<<4;
  if ((pad.axes[1] ?? 0) > 0.5) m |= 1<<5;
  if ((pad.axes[0] ?? 0) < -0.5) m |= 1<<6;
  if ((pad.axes[0] ?? 0) > 0.5) m |= 1<<7;
  if (pressed("A")) m |= 1<<8;
  if (pressed("X")) m |= 1<<9;
  if (pressed("L")) m |= 1<<10;
  if (pressed("R")) m |= 1<<11;
  return m;
}
