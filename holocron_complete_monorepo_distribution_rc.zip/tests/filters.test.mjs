
import test from "node:test";
import assert from "node:assert/strict";
import { OrderedFilterPipeline, QueryFilter, CompatibilityFilter, SortFilter } from "../packages/sdk/src/index.js";

test("filters are deterministic", () => {
  const pipeline = new OrderedFilterPipeline()
    .use(new SortFilter(x => x.title))
    .use(new CompatibilityFilter())
    .use(new QueryFilter(x => x.title));
  assert.deepEqual(pipeline.filters.map(f => f.id), ["query","compatibility","sort"]);
});

test("query + compatibility + sort pipeline", () => {
  const items = [
    { title:"Zeta RPG", compatibility:90 },
    { title:"Alpha RPG", compatibility:99 },
    { title:"Other", compatibility:100 }
  ];
  const result = new OrderedFilterPipeline()
    .use(new QueryFilter(x => x.title))
    .use(new CompatibilityFilter())
    .use(new SortFilter(x => x.title))
    .run(items, { query:"rpg", minCompatibility:95 });
  assert.deepEqual(result.map(x => x.title), ["Alpha RPG"]);
});
