
import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { HolocronCore } from "../packages/sdk/src/index.js";

const wasmPath = new URL("../packages/core-wasm/dist/holocron-snes-core.wasm", import.meta.url);

test("stable core ABI opens as major v1", async () => {
  const bytes = await readFile(wasmPath);
  const core = await new HolocronCore().open(bytes);
  assert.equal(core.version().major, 1);
});

test("synthetic ROM runs and state round-trips", async () => {
  const bytes = await readFile(wasmPath);
  const core = await new HolocronCore().open(bytes);
  core.reset();

  // Small synthetic loop using opcodes supported by the current dev core.
  const rom = new Uint8Array([0xA9, 0x01, 0xE8, 0xEA, 0x4C, 0x00, 0x80]);
  core.loadRom(rom);
  core.setController1(0x0101);
  core.runFrame();

  const frame = core.framebuffer();
  assert.equal(frame.width, 256);
  assert.equal(frame.height, 224);
  assert.equal(frame.format, 1);

  const state = core.saveState();
  assert.ok(state.length > 1000);
  core.runFrame();
  core.loadState(state);
});
